﻿using System;

namespace TrackerList.Model
{
    public interface IEntityBase
    {
        int Id { get; set; }
    }
}
